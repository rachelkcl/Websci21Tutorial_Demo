var url = (function () {
  function r(r, c) {
    var t,
      o = {};
    if ("tld?" === r) return n();
    if (((c = c || window.location.toString()), !r)) return c;
    if (((r = r.toString()), (t = c.match(/^mailto:([^\/].+)/))))
      (o.protocol = "mailto"), (o.email = t[1]);
    else {
      if (
        ((t = c.match(/(.*?)\/#\!(.*)/)) && (c = t[1] + t[2]),
        (t = c.match(/(.*?)#(.*)/)) && ((o.hash = t[2]), (c = t[1])),
        o.hash && r.match(/^#/))
      )
        return e(r, o.hash);
      if (
        ((t = c.match(/(.*?)\?(.*)/)) && ((o.query = t[2]), (c = t[1])),
        o.query && r.match(/^\?/))
      )
        return e(r, o.query);
      if (
        ((t = c.match(/(.*?)\:?\/\/(.*)/)) &&
          ((o.protocol = t[1].toLowerCase()), (c = t[2])),
        (t = c.match(/(.*?)(\/.*)/)) && ((o.path = t[2]), (c = t[1])),
        (o.path = (o.path || "").replace(/^([^\/])/, "/$1")),
        r.match(/^[\-0-9]+$/) && (r = r.replace(/^([^\/])/, "/$1")),
        r.match(/^\//))
      )
        return a(r, o.path.substring(1));
      if (
        ((t =
          (t = a("/-1", o.path.substring(1))) && t.match(/(.*?)\.([^.]+)$/)) &&
          ((o.file = t[0]), (o.filename = t[1]), (o.fileext = t[2])),
        (t = c.match(/(.*)\:([0-9]+)$/)) && ((o.port = t[2]), (c = t[1])),
        (t = c.match(/(.*?)@(.*)/)) && ((o.auth = t[1]), (c = t[2])),
        o.auth &&
          ((t = o.auth.match(/(.*)\:(.*)/)),
          (o.user = t ? t[1] : o.auth),
          (o.pass = t ? t[2] : void 0)),
        (o.hostname = c.toLowerCase()),
        "." === r.charAt(0))
      )
        return a(r, o.hostname);
      n() &&
        (t = o.hostname.match(n())) &&
        ((o.tld = t[3]),
        (o.domain = t[2] ? t[2] + "." + t[3] : void 0),
        (o.sub = t[1] || void 0)),
        (o.port = o.port || ("https" === o.protocol ? "443" : "80")),
        (o.protocol = o.protocol || ("443" === o.port ? "https" : "http"));
    }
    return r in o ? o[r] : "{}" === r ? o : void 0;
  }

  function n() {
    return new RegExp(
      /(.*?)\.?([^\.]*?)\.(gl|com|net|org|biz|ws|in|me|co\.uk|co|org\.uk|ltd\.uk|plc\.uk|me\.uk|edu|mil|br\.com|cn\.com|eu\.com|hu\.com|no\.com|qc\.com|sa\.com|se\.com|se\.net|us\.com|uy\.com|ac|co\.ac|gv\.ac|or\.ac|ac\.ac|af|am|as|at|ac\.at|co\.at|gv\.at|or\.at|asn\.au|com\.au|edu\.au|org\.au|net\.au|id\.au|be|ac\.be|adm\.br|adv\.br|am\.br|arq\.br|art\.br|bio\.br|cng\.br|cnt\.br|com\.br|ecn\.br|eng\.br|esp\.br|etc\.br|eti\.br|fm\.br|fot\.br|fst\.br|g12\.br|gov\.br|ind\.br|inf\.br|jor\.br|lel\.br|med\.br|mil\.br|net\.br|nom\.br|ntr\.br|odo\.br|org\.br|ppg\.br|pro\.br|psc\.br|psi\.br|rec\.br|slg\.br|tmp\.br|tur\.br|tv\.br|vet\.br|zlg\.br|br|ab\.ca|bc\.ca|mb\.ca|nb\.ca|nf\.ca|ns\.ca|nt\.ca|on\.ca|pe\.ca|qc\.ca|sk\.ca|yk\.ca|ca|cc|ac\.cn|com\.cn|edu\.cn|gov\.cn|org\.cn|bj\.cn|sh\.cn|tj\.cn|cq\.cn|he\.cn|nm\.cn|ln\.cn|jl\.cn|hl\.cn|js\.cn|zj\.cn|ah\.cn|gd\.cn|gx\.cn|hi\.cn|sc\.cn|gz\.cn|yn\.cn|xz\.cn|sn\.cn|gs\.cn|qh\.cn|nx\.cn|xj\.cn|tw\.cn|hk\.cn|mo\.cn|cn|cx|cz|de|dk|fo|com\.ec|tm\.fr|com\.fr|asso\.fr|presse\.fr|fr|gf|gs|co\.il|net\.il|ac\.il|k12\.il|gov\.il|muni\.il|ac\.in|co\.in|org\.in|ernet\.in|gov\.in|net\.in|res\.in|is|it|ac\.jp|co\.jp|go\.jp|or\.jp|ne\.jp|ac\.kr|co\.kr|go\.kr|ne\.kr|nm\.kr|or\.kr|li|lt|lu|asso\.mc|tm\.mc|com\.mm|org\.mm|net\.mm|edu\.mm|gov\.mm|ms|nl|no|nu|pl|ro|org\.ro|store\.ro|tm\.ro|firm\.ro|www\.ro|arts\.ro|rec\.ro|info\.ro|nom\.ro|nt\.ro|se|si|com\.sg|org\.sg|net\.sg|gov\.sg|sk|st|tf|ac\.th|co\.th|go\.th|mi\.th|net\.th|or\.th|tm|to|com\.tr|edu\.tr|gov\.tr|k12\.tr|net\.tr|org\.tr|com\.tw|org\.tw|net\.tw|ac\.uk|uk\.com|uk\.net|gb\.com|gb\.net|vg|sh|kz|ch|info|ua|gov|name|pro|ie|hk|com\.hk|org\.hk|net\.hk|edu\.hk|us|tk|cd|by|ad|lv|eu\.lv|bz|es|jp|cl|ag|mobi|eu|co\.nz|org\.nz|net\.nz|maori\.nz|iwi\.nz|io|la|md|sc|sg|vc|tw|travel|my|se|tv|pt|com\.pt|edu\.pt|asia|fi|com\.ve|net\.ve|fi|org\.ve|web\.ve|info\.ve|co\.ve|tel|im|gr|ru|net\.ru|org\.ru|hr|com\.hr|ly|xyz)$/
    );
  }

  function a(r, c) {
    var t = r.charAt(0),
      o = c.split(t);
    return t === r
      ? o
      : o[(r = parseInt(r.substring(1), 10)) < 0 ? o.length + r : r - 1];
  }

  function e(r, c) {
    for (
      var t,
        o = r.charAt(0),
        n = c.split("&"),
        a = [],
        e = {},
        m = [],
        i = r.substring(1),
        s = 0,
        h = n.length;
      s < h;
      s++
    )
      if (
        "" !==
        (a = (a = n[s].match(/(.*?)=(.*)/)) || [n[s], n[s], ""])[1].replace(
          /\s/g,
          ""
        )
      ) {
        if (
          ((a[2] =
            ((t = a[2] || ""), decodeURIComponent(t.replace(/\+/g, " ")))),
          i === a[1])
        )
          return a[2];
        (m = a[1].match(/(.*)\[([0-9]+)\]/))
          ? ((e[m[1]] = e[m[1]] || []), (e[m[1]][m[2]] = a[2]))
          : (e[a[1]] = a[2]);
      }
    return o === r ? e : e[i];
  }
  return r;
})();
//url('domain', test)

function tldurl(domain) {
  if (String(domain).startsWith(".")) {
    domain = domain.substr(1);
  }

  if (String(url("domain", domain)) != "undefined") {
    return url("domain", domain);
  }
  if (String(url("domain", domain)) == "undefined") {
    //return domain.replace(/^\.|www\.+|\s+$/g, "");
    return domain;
  }
}

function autocontrol() {
    var autoCollectSetting  = document.getElementById("auto-collection-control");
    autoCollectSetting.addEventListener("click", async () => {
      localStorage["auto-collection-control"] = autoCollectSetting.checked;
      localStorage["consent-notice-user"] = autoCollectSetting.checked;
	  ShowModal();
      /*if (autoCollectSetting.checked == true) {
        ShowModal();
      }*/
    });
}

function ShowModal() {
  document.getElementsByClassName("modal")[0].style.display = "";
  var confirm_btn = document.querySelector(".modal-confirm");
  confirm_btn.addEventListener("click", async () => {
    localStorage["consent-notice-user"] = true;
    document.getElementById("auto-collection-control").checked = true;
    document.querySelector(".modal ").style.display = "none";
  });

  var cancel_btn = document.querySelector(".modal-cancel");
  cancel_btn.addEventListener("click", async () => {
    document.querySelector(".modal ").style.display = "none";
    document.getElementById("auto-collection-control").checked = false;
    localStorage["auto-collection-control"] = false;
  });
}

function AddFPInTable(name, value) {
  document.getElementById("TPTable").style.display = "none";
  document.getElementById("FPTable").style.display = "";

  trNodes = document.getElementById("FPTable").querySelectorAll("tr");
  for (var t = 0; t < trNodes.length; t++) {
    var each = trNodes[t];
    if (each.getElementsByTagName("td").length > 0) {
      if (name == each.getElementsByTagName("td")[0].innerText) {
        return;
      }
    }
  }
  var table = document.getElementById("Tabletbody");

  var newline = document.createElement("tr");
  var cookiename = document.createElement("td");
  var cookievalue = document.createElement("td");
  var op = document.createElement("td");
  var cancelbtn = document.createElement("button");
  cookiename.innerHTML = null;
  cookievalue.innerHTML = null;
  cancelbtn.addEventListener(
    "click",
    function () {
      $(this).parents("tr").remove();
    },
    false
  );
  cancelbtn.innerHTML = "delete";
  cancelbtn.setAttribute("class", "Cancelbtn");
  table.appendChild(newline);
  newline.appendChild(cookiename);
  newline.appendChild(cookievalue);
  newline.appendChild(op);
  op.appendChild(cancelbtn);

  var tr = document.getElementsByTagName("tr");

  cookiename.innerHTML = name;
  cookievalue.innerHTML = value;

  $(".FPCookieTable tbody td").hover(function () {
    var value = $(this).text();
    $(this).attr("title", value);
  });
}

function TabFPCookie() {
  chrome.tabs.query(
    {
      active: true,
    },
    function (tab) {
      chrome.cookies.getAll(
        {
          url: tab[0].url,
        },
        function (cookies) {
          for (var cookie_obj of cookies) {
            AddFPInTable(cookie_obj["name"], cookie_obj["value"]);
          }
        }
      );
    }
  );
}

function AddTPInTable(domain, name, value) {
  document.getElementById("FPTable").style.display = "none";
  document.getElementById("TPTable").style.display = "";

  trNodes = document.getElementById("TPTable").querySelectorAll("tr");
  for (var t = 0; t < trNodes.length; t++) {
    var each = trNodes[t];
    if (each.getElementsByTagName("td").length > 1) {
      if (name == each.getElementsByTagName("td")[1].innerText) {
        return;
      }
    }
  }
  var table = document.getElementById("TPTabletbody");
  var newline = document.createElement("tr");
  var cookiedomain = document.createElement("td");
  var cookiename = document.createElement("td");
  var cookievalue = document.createElement("td");
  var op = document.createElement("td");
  var cancelbtn = document.createElement("button");
  cookiedomain.innerHTML = null;
  cookiename.innerHTML = null;
  cookievalue.innerHTML = null;
  cancelbtn.addEventListener(
    "click",
    function () {
      $(this).parents("tr").remove();
    },
    false
  );
  cancelbtn.innerHTML = "delete";
  cancelbtn.setAttribute("class", "Cancelbtn");
  table.appendChild(newline);
  newline.appendChild(cookiedomain);
  newline.appendChild(cookiename);
  newline.appendChild(cookievalue);
  newline.appendChild(op);
  op.appendChild(cancelbtn);

  var tr = document.getElementsByTagName("tr");

  cookiedomain.innerHTML = domain;
  cookiename.innerHTML = name;
  cookievalue.innerHTML = value;

  $(".TPCookieTable tbody td").hover(function () {
    var value = $(this).text();
    $(this).attr("title", value);
  });
}

function TabTPCookie_webRequest() {
  chrome.webRequest.onResponseStarted.addListener(
    (response) => {
      var url = response.url;
      var tab = response.tabId;
      chrome.cookies.getAll(
        {
          url,
        },
        function (cookies) {
          chrome.tabs.getSelected(null, function (tab) {
            var TPcookies = cookies
              .map((x) => {
                if (tldurl(Object(x).domain) != tldurl(tab.url)) {
                  return x;
                } else {
                  return;
                }
              })
              .filter(Boolean);

            if (TPcookies.length > 0) {
              for (var cookie_obj of TPcookies) {
                AddTPInTable(
                  tldurl(cookie_obj["domain"]),
                  cookie_obj["name"],
                  cookie_obj["value"]
                );
              }
            }
          });
        }
      );
    },
    {
      urls: ["<all_urls>"],
    }
  );
}

function TabTPCookie() {
  chrome.tabs.query(
    {
      active: true,
    },
    function (tab) {
      chrome.tabs.executeScript(
        tab[0].id,
        {
          code: 'performance.getEntriesByType("resource").map(e => e.name)',
        },
        (data) => {
          var CurrentUrl = tab[0].url;
          if (chrome.runtime.lastError || !data || !data[0]) return;
          var urls = data[0].map((url) => url.split(/[#?]/)[0]);
          var uniqueUrls = [...new Set(urls).values()].filter(Boolean);
          uniqueUrls.map((url) =>
            chrome.cookies.getAll(
              {
                url,
              },
              function (cookies) {
                var TPcookies = cookies
                  .map((x) => {
                    if (tldurl(Object(x).domain) != tldurl(CurrentUrl)) {
                      return x;
                    } else {
                      return;
                    }
                  })
                  .filter(Boolean);
                if (TPcookies.length > 0) {
                  for (var cookie_obj of TPcookies) {
                    AddTPInTable(
                      tldurl(cookie_obj["domain"]),
                      cookie_obj["name"],
                      cookie_obj["value"]
                    );
                  }
                }
              }
            )
          );
        }
      );
    }
  );
}

function unique(arr) {
  if (!Array.isArray(arr)) {
    return;
  }
  arr = arr.sort();
  var arrry = [arr[0]];
  for (var i = 1; i < arr.length; i++) {
    if (arr[i] !== arr[i - 1]) {
      arrry.push(arr[i]);
    }
  }
  return arrry;
}

function Statistic_Tab() {
  chrome.tabs.query(
    {
      active: true,
    },
    function (tab) {
      chrome.tabs.executeScript(
        tab[0].id,
        {
          code: 'performance.getEntriesByType("resource").map(e => e.name)',
        },
        (data) => {
          var CurrentUrl = tab[0].url;
          if (chrome.runtime.lastError || !data || !data[0]) return;
          var urls = data[0].map((url) => url.split(/[#?]/)[0]);

          var uniqueUrls = [...new Set(urls).values()].filter(Boolean);
          Promise.all(
            uniqueUrls.map(
              (url) =>
                new Promise((resolve) => {
                  chrome.cookies.getAll(
                    {
                      url,
                    },
                    resolve
                  );
                })
            )
          ).then((results) => {
            var cookies = [
              ...new Map(
                [].concat(...results).map((c) => [JSON.stringify(c), c])
              ).values(),
            ];
            var TPcookies = cookies
              .map((x) => {
                if (tldurl(Object(x).domain) != tldurl(CurrentUrl)) {
                  return x;
                } else {
                  return;
                }
              })
              .filter(Boolean);

            var NeedStore_CookiesInTab = {};
            NeedStore_CookiesInTab["hostname"] = tldurl(CurrentUrl);
            NeedStore_CookiesInTab["CookiesInTab"] = cookies;
            NeedStore_CookiesInTab["TPCookiesInTab"] = cookies
              .map((x) => {
                if (tldurl(Object(x).domain) != tldurl(CurrentUrl)) {
                  return x;
                } else {
                  return;
                }
              })
              .filter(Boolean);

            NeedStore_CookiesInTab["uThirdParties"] = unique(
              cookies.map((x) => {
                if (
                  tldurl(Object.values(Object(x).valueOf("domain"))[0]).split(
                    "."
                  )[0] != tldurl(CurrentUrl).split(".")[0]
                ) {
                  // if the tld not just secondlevel domain is not different
                  return tldurl(Object.values(Object(x).valueOf("domain"))[0]);
                } else {
                  return;
                }
              })
            ).filter(Boolean);

            for (var thname of document
              .getElementById("FPTable")
              .getElementsByTagName("th")) {
              if (thname.innerText == "Cookie Name") {
                thname.innerText = "#TPcookies";
              }
              if (thname.innerText == "Cookie Value") {
                thname.innerText = "#TPdomain(unique)";
              }
            }

            var elmtTable = document.getElementById("Tabletbody");
            var tableRows = elmtTable.getElementsByTagName("tr");
            var rowCount = tableRows.length;

            for (var x = rowCount - 1; x >= 0; x--) {
              elmtTable.removeChild(tableRows[x]);
            }

            AddFPInTable(
              NeedStore_CookiesInTab["TPCookiesInTab"].length,
              NeedStore_CookiesInTab["uThirdParties"].length
            );
          });
        }
      );
    }
  );
}


function findKey(obj, value, compare = (a, b) => a === b) {
  result = Object.keys(obj).find((k) => obj[k].indexOf(value) > -1);
  if (String(result) != "undefined") {
    return result;
  }
  if (String(result) == "undefined") {
    return value;
  }
}

function TabIDshow() {
  if (document.getElementById("thirdpartyList").style.display == "none") {
    document.getElementById("thirdpartyList").style.display = "";
  } else {
    if (document.getElementById("thirdpartyList").innerHTML != "") {
      document.getElementById("thirdpartyList").style.display = "none";
    } else {
      var xhr = new XMLHttpRequest();
      xhr.open("GET", "../js/entities.json", false);
      xhr.send();
      var entityObj = JSON.parse(xhr.response);

      chrome.tabs.query(
        {
          active: true,
        },
        function (tab) {
          document.getElementById("tabid_show").innerHTML = tab[0].id;
          chrome.tabs.executeScript(
            tab[0].id,
            {
              code: 'performance.getEntriesByType("resource").map(e => e.name)',
            },
            (data) => {
              var CurrentUrl = tab[0].url;
              if (chrome.runtime.lastError || !data || !data[0]) return;
              var urls = data[0].map((url) => url.split(/[#?]/)[0]);
              if (urls.length == 0) {
                document.getElementById("thirdpartyList").innerHTML =
                  "no third party loading in this tab";
                return;
              }

              var TPurls = urls
                .map((x) => {
                  if (new URL(x).protocol == "chrome-extension:") {
                    return;
                  }
                  if (tldurl(x) != tldurl(CurrentUrl)) {
                    return tldurl(x);
                  } else {
                    return;
                  }
                })
                .filter(Boolean);
              var uniqueTPdomain = unique(TPurls);
              var ul = document.createElement("ul");
              ul.setAttribute("id", "proList");
              document.getElementById("thirdpartyList").appendChild(ul);
              uniqueTPdomain.forEach(uniqueTPdomainList);

              function uniqueTPdomainList(element, index, arr) {
                var li = document.createElement("li");
                li.setAttribute("class", "item");
                ul.appendChild(li);
                li.innerHTML =
                  li.innerHTML +
                  element +
                  " (" +
                  findKey(entityObj, element) +
                  ")";
              }
            }
          );
        }
      );
    }
  }
}

function sendServer() {
  var xhr = new XMLHttpRequest();
  xhr.open("GET", "https://demo.com/phpFilePath.php", false);
  xhr.send(JSON.stringify(JSONData, " ", 2));
}

function indexedDBcreates() {
  var indexes = [
    "hostname", // Primary key
    "isVisible",
    "firstParty",
  ];
  var db = new Dexie("indexedDB_demo");
  var indexedKey = indexes.join(", ");
  db.version(1).stores({
    indexedKey,
  });
  db.open();
  location.reload();
}
const storetmp = {
    db: null,
    async init() {
      if (!this.db) {
        this.makeNewDatabase();
      }
      chrome.runtime.onMessage.addListener((m) => store.messageHandler(m));
    },
    indexes: [
      "hostname", // Primary key
      "isVisible",
      "firstParty",
    ],
    makeNewDatabase() {
      this.db = new Dexie("indexedDB_demo");
      var websites = this.indexes.join(", ");

      this.db.version(1).stores({
        websites,
      });
      this.db.open();
    },
  };
  
function indexedDBcreate() {
  storetmp.init();
  location.reload();
}

async function writeDB() {
  var JSONsample = {
    hostname: "bat.bing.com",
    firstPartyHostnames: [
      "developers.google.com",
      "www.watchnation.com",
      "safesend.soton.ac.uk",
    ],
    isVisible: 1,
    target: "bat.bing.com",
    origin: "www.watchnation.com",
    firstParty: 0,
  };
  var db = await store.db.open();
  await db.websites.put(JSONsample);
}


async function InsertJS() {
  var insertScript = document.getElementById("tcontent").value;
  if (insertScript.startsWith("function")) {
    runJS = insertScript.slice(
      insertScript.indexOf(" "),
      insertScript.indexOf("{")
    );
    a = new Function(insertScript + runJS);
    a();
  }
  if (insertScript.startsWith("async")) {
    runJS = insertScript.slice(
      insertScript.indexOf(" "),
      insertScript.indexOf("{")
    );
	var AsyncFunction = Object.getPrototypeOf(async function(){}).constructor;
    a = new AsyncFunction(insertScript + 'await' + runJS.replace("function",""));
    await a();
  }
  else {
    var funcStr = insertScript;
    var funcTest = new Function("return " + funcStr);
    funcTest();
  }
  document.getElementsByClassName("JSinput")[0].style.display = "";
}

function BindByDom() {
  try {
    var htmlBtns = document.getElementsByTagName("button");
    for (var i = 0; i < htmlBtns.length; ++i) {
      htmlBtns[i].onclick = function () {
        var id = this.getAttribute("id");
        if ((id != "InsertJS") & (id != "funcTest")&(id != "selectorValue")) {
          document.getElementsByClassName("JSinput")[0].style.display = "";
          console.log("id = " + id);
        }
      };
    }
  } catch (error) {
    console.log(error);
  }
}

function openTest(){
	document.getElementsByClassName("JSinput")[0].style.display = "";
}

function selectorValue() {
  var index = document.getElementById("selectElem").selectedIndex;
  document.getElementById("selectElem").options[index].value;
  var obj = document.getElementById("selectElem");
  for (i = 0; i < obj.length; i++) {
    if (obj[i].selected == true) {
      var SelectedText = obj[i].value;
      var funcStr = String(SelectedText) + ".toString()";
      var ShowFunc = new Function(
        'document.getElementById("tcontent").innerHTML = ' + funcStr
      );
      ShowFunc();
    }
  }
}


async function downloadData(){
	var downloadData = await store.db.websites.toArray();
	var blob_download = new Blob(
		[JSON.stringify(downloadData,' ' , 2)], 
		{type : 'application/json'});
	var downloadurl = window.URL.createObjectURL(blob_download);
	var downloading = chrome.downloads.download({
		url : downloadurl,
		filename : 'downloadData.json'
		});
}


window.onload = function () {
  BindByDom();
  var insert = document.getElementById("InsertJS");
  insert.addEventListener("click", InsertJS);
  var selector = document.getElementById("selectorValue");
  selector.addEventListener("click", selectorValue);
  var collection = document.getElementById("auto-collection-control");
  collection.addEventListener("click", openTest);
  /*
	var mb1 = document.getElementById("auto-collection-control");
	mb1.addEventListener("click", autocontrol);
	var mb2 = document.getElementById("TabFPCookie");
	mb2.addEventListener("click", TabFPCookie);
	var mb3 = document.getElementById("TabTPCookie");
	mb3.addEventListener("click", TabTPCookie);
	var mb4 = document.getElementById("StatisticTab");
	mb4.addEventListener("click", Statistic_Tab);
	var mb5 = document.getElementById("TabID");
	mb5.addEventListener("click", TabIDshow);
	var mb8 = document.getElementById("indexedDBcreate");
	mb8.addEventListener("click", indexedDBcreate);
	var mb9 = document.getElementById("TabTPCookie_webRequest");
	mb9.addEventListener("click", TabTPCookie_webRequest);
	var mb10 = document.getElementById("writeDB");
	mb10.addEventListener("click", writeDB);
	*/
};
